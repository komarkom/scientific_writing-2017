/************************************************************
* $Id: main.c,v 1.13 2008/08/08 11:08:35 mechanoid Exp $
*      
* OCR: symbol segmentator
*
*       OS : FreeBSD 6.2
* COMPILER : GNU project C and C++ Compiler (gcc 3.4.6)
*   AUTHOR : Evgeny S. Borisov
*
*  Glushkov Institute of Cybernetics
*  National Academy of Sciences of Ukraine
* 
*    http://www.mechanoid.kiev.ua
*  e-mail: ocr@mechanoid.kiev.ua
* 
************************************************************/
#include <gdk/gdk.h>
#include <stdio.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include <errno.h>
#include <math.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/uio.h>
#include <unistd.h>
#include <fcntl.h>
#include <libgen.h>

#define B_HIGH    255
#define B_LOW     0
#define B_MEAN    224.0
#define B_FACTOR  0.5
#define D_FACTOR  0.3

// 1008x23
// 1864x45

gfloat    bm=(B_HIGH-B_MEAN); // mean brightness image
gfloat    bs=((B_HIGH-B_MEAN)*B_FACTOR); // symbol bound brightness


GdkPixbuf *pixbuf; // input picture
guchar    *pixels; // picture byte array

gint      *w0; // symbol bounds positions liest
gint      w0_count=0; // bounds array size

gint      *w1; // symbol bounds positions list
gint      w1_count=0; // bounds array size

gint      *w2; // symbol bounds positions list
gint      w2_count=0; // bounds array size

gfloat    *brg; // mean brightness characteristic vector
gint      w; // image width in pixels
gint      h; // image height in pixels
gint      nch;   // channels number (bytes to pixels, nch=3 for RGB )
gint      rwstr; // bytes to rows

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
* load image from file to buffer                                  
*/
GdkPixbuf* img_load(char filename[]) {
   GdkPixbuf *pb;
   GError    *err=NULL;
   pb=gdk_pixbuf_new_from_file(filename,&err);
   if(err!=NULL){fprintf(stderr,err->message);g_error_free(err);return NULL;}
   return pb;
}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
* save image from buffer to file
*/
int img_save(GdkPixbuf *pb,char filename[]) {
   GError *err=NULL;
   g_return_val_if_fail(pb!=NULL,1);
   gdk_pixbuf_save(pb,filename,"bmp",&err,NULL);
   if(err!=NULL){fprintf(stderr,err->message);g_error_free(err);return 2;}
   return 0;
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
int segm_init(gchar filename[]){
   pixbuf=img_load(filename);
   g_return_val_if_fail(pixbuf!=NULL,1);
   pixels=gdk_pixbuf_get_pixels(pixbuf);
   g_return_val_if_fail(pixels!=NULL,2);

   // get image parameters
   h=gdk_pixbuf_get_height(pixbuf);
   w=gdk_pixbuf_get_width(pixbuf);
   nch=gdk_pixbuf_get_n_channels (pixbuf);
   rwstr=gdk_pixbuf_get_rowstride(pixbuf);


   // brightness characteristic vector
   brg=g_malloc(w*sizeof(gfloat));
   g_return_val_if_fail(brg!=NULL,3);
   memset(brg,0,w*sizeof(gfloat));

   // symbol bounds positions
   w0=g_malloc(w*sizeof(gint)); g_return_val_if_fail(w0!=NULL,4);
   w1=g_malloc(w*sizeof(gint)); g_return_val_if_fail(w1!=NULL,5);
   w2=g_malloc(w*sizeof(gint)); g_return_val_if_fail(w2!=NULL,6);

   return 0;
}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
*/
int write_out(gchar *outfile,gint *bounds,gint bounds_count) {
   GdkPixbuf*  pixbuf_copy;
   guchar      *pixels_copy;
   gint i,j,k;

   pixbuf_copy=gdk_pixbuf_copy(pixbuf);
   g_return_val_if_fail(pixbuf_copy!=NULL,1);
   pixels_copy=gdk_pixbuf_get_pixels(pixbuf_copy);
   g_return_val_if_fail(pixels_copy!=NULL,2);

   for( j=0 ; j<bounds_count ; j++ ) {
	  for( i=0 ; i<h ; i++ ) { 
		 k=(bounds[j]*nch)+(i*rwstr); 
		 // start word line
		 if(nch==3){ // green line (only for RGB image)
			pixels_copy[k+0]=B_LOW; 
			pixels_copy[k+1]=B_HIGH;
			pixels_copy[k+2]=B_LOW; 
		 } else { // black line
			pixels_copy[k]=B_LOW; 
		 }
  	  } 
   }
   img_save(pixbuf_copy,outfile);
   gdk_pixbuf_unref(pixbuf_copy);

   return 0;
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
int segm_destroy(){
   if(pixbuf!=NULL){gdk_pixbuf_unref(pixbuf);}
   if(brg!=NULL){ g_free(brg);}
   if(w0!=NULL){g_free(w0);}
   if(w1!=NULL){g_free(w1);}
   if(w2!=NULL){g_free(w2);}
   return 0;
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
* make brightness characteristic vector
*/
int columns_characteristic(){
   guchar *p;
   gint   i,j;

   for( i=0 ; i<w ; i++ ) { 
      for( j=0 ; j<h ; j++ ) {
		 p=pixels+(j*rwstr)+(i*nch); 
		 brg[i]+=( B_HIGH - p[0]); 
      }
 	  brg[i]=brg[i]/h;
   }
   return 0;
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
*   return max brightness value in column i
*/
guchar max_brg(gint i) {
   guchar *p;
   guchar bmax,b;
   gint   j;

   if((i+1)>w){ return 0; }
   p=pixels+(i*nch);
   bmax=(B_HIGH-p[0]);

   for( j=1 ; j<h ; j++ ) {
	  p=pixels+(j*rwstr)+(i*nch);
	  b=(B_HIGH-p[0]); 
	  bmax=(b>bmax)?b:bmax;
   }

   return bmax;
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
* find columns with minimum brightness (start bounds list)
*/
int make_w0() {
   gfloat bmin;
   gint   imin;
   gint   i,j;
   gint   d;

   // symbol bounds search interval
   d=h*D_FACTOR;

   w0_count=0;
   for( i=0 ; i<w ; i++ ) { 
 	  bmin=brg[i]; imin=i;
	  for( j=1 ; (j<d)&&(j<(w-i)); j++ ) { 
		 if(brg[i+j]<bmin) { bmin=brg[i+j]; imin=i+j; }
	  }
	  i=imin+1;
	  w0[w0_count++]=imin;
   }
   return 0;
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
* find in w0 columns with brightness condition
*/
int make_w1() {
   gboolean fl,fc,fr;
   gint     i;   
   gint     j;   
   gint     di=2;

   for( i=0,w1_count=0,j=w0[0] ; i<w0_count ; j=w0[i++] ) { 
	  fl=((j-di)>0)?(brg[j-di]>bs):1;
	  fr=((j+di)<w)?(brg[j+di]>bs):1;
	  fc=(brg[j]<bs);
	  if( fc && (fr||fl) ) { w1[w1_count++]=j; }
   }

   return 0;
}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
*  find max brightness value in column i
*  between lines number h1 and h2
*  return line number max brightness
*/
gint max_brg_index(gint i,gint h1,gint h2) {
   guchar bmax,b;
   guchar *p;
   gint   j,jmax;

   if((i+1)>w){ return 0; }
   p=pixels+(i*nch);
   bmax=(B_HIGH-p[0]);
   jmax=0;

   for( j=h1 ; j<h2 ; j++ ) {
	  p=pixels+(j*rwstr)+(i*nch);
	  b=(B_HIGH-p[0]); 
	  if(b>bmax){ bmax=b;jmax=j; }
   }
   return jmax;
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
*  find right and left links column k
*  return true if both links exist
*/
gboolean check_links(gint k) {
   gint mlc,mll,mlr;
   gint mmc,mml,mmr;
   gint mhc,mhl,mhr;
   gint h0,h1,h2,h3,hd;
   gint cd=1;
   gboolean  link_l, link_r, link;

   // mean symbol height -- 70% of image height
   h0=h*0.7;
   // top and botom border height
   hd=(h-h0)*0.5;
   // low level height
   h1=h0*0.3+hd;
   // middle level height
   h2=h0*0.4+h1;
   // hight level height
   h3=h0*0.3+h2;
   
   // max brightness position for low level
   mlc=max_brg_index(k,0,h1);
   mll=max_brg_index(k-cd,0,h1);
   mlr=max_brg_index(k+cd,0,h1);

   // max brightness position for middle level
   mmc=max_brg_index(k,h1,h2);
   mml=max_brg_index(k-cd,h1,h2);
   mmr=max_brg_index(k+cd,h1,h2);

   // max brightness position for hight level
   mhc=max_brg_index(k,h2,h3);
   mhl=max_brg_index(k-cd,h2,h3);
   mhr=max_brg_index(k+cd,h2,h3);

   // check left link condition
   link_l=(mlc==mll)||(mmc==mml)||(mhc==mhl);
   // check right link condition
   link_r=(mlc==mlr)||(mmc==mmr)||(mhc==mhr);
 
   link=(link_l && link_r);

   return link;
}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
* check brightness condition for column k   
*/
gboolean check_links_brg(gint k) {
   guchar mbl,mbc,mbr;
   gboolean fl,fr;

   mbl=max_brg(k-1);
   mbc=max_brg(k);
   mbr=max_brg(k+1);

   fl=(brg[k] < mbl) && (mbc > 2*abs(mbl-mbc)) ;
   fr=(brg[k] < mbr) && (mbc > 2*abs(mbr-mbc)) ;

   return (fl && fr);
}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
* find in w1 columns with link and bounds distance condition
*/
int make_w2() {
   gboolean f1,f2,f3,f;
   gint     i;
   gint     dmin=h*0.4;

   w2_count=0;
   w2[0]=0;
   for( i=0 ; i<w1_count ; i++ ) { 
      // check column links
	  f1=check_links_brg(w1[i]);
	  f2=check_links(w1[i]);
	  // check bounds distance
      f3=(w2_count>1) ? ((w1[i]-w2[w2_count-1])<dmin) : 0;

	  f= ((!f1) && (!f2) && (!f3))||
	     ((!f1) &&   f2  && (!f3))||
		 ( (f1) && (!f2) && (!f3));

	  if(f) { w2[w2_count++]=w1[i]; }
   }
   return 0;
}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
*/
int main(int argc, char *argv[]) {
   if(argc!=2){ fprintf(stderr,"%s <input>\n",argv[0]);return 4; } 

   gdk_init(&argc, &argv);

   if(segm_init(argv[1])){segm_destroy();return 1;}

   columns_characteristic();
   make_w0();
   make_w1();
   make_w2();

   write_out("w0.bmp",w0,w0_count);
   write_out("w1.bmp",w1,w1_count);
   write_out("w2.bmp",w2,w2_count);

   segm_destroy();
   return 0;
}
