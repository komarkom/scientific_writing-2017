/************************************************************
* $Id: main.c,v 1.12 2008/01/03 11:07:52 mechanoid Exp mechanoid $
*      
* OCR: word segmentator
*
*       OS : FreeBSD 6.2
* COMPILER : GNU project C and C++ Compiler (gcc 3.4.6)
*   AUTHOR : Evgeny S. Borisov
*
*  Glushkov Institute of Cybernetics
*  National Academy of Sciences of Ukraine
* 
*    http://www.mechanoid.kiev.ua
*  e-mail: ocr@mechanoid.kiev.ua
* 
************************************************************/
#include <gdk/gdk.h>
#include <stdio.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include <errno.h>
#include <math.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/uio.h>
#include <unistd.h>
#include <fcntl.h>
#include <libgen.h>

#define BASE_HEIGHT    20.0

#define B_HIGH         255
#define B_LOW          0
#define B_MEAN         224.0
#define B_CNTRST       200.0
#define B1_FACTOR      0.5
#define B2_FACTOR      0.4

// 1008x23
// 1864x45

typedef struct {
	gint begin;
	gint end;
} bound_t; 

gfloat    bm=(B_HIGH-B_MEAN); // mean brightness image
gfloat    b1=((B_HIGH-B_MEAN)*B1_FACTOR); // word start bound brightness
gfloat    b2=((B_HIGH-B_MEAN)*B2_FACTOR); // word end bound brightness

gint      bcb=B_CNTRST; // brightness bound for contrast increase procedure
gchar     bh=B_HIGH; // max brightness
gchar     bl=B_LOW;  // min brightness

gint      d1; // image segment size in pixels to check word start
gint      d2; // image segment size in pixels to check word end

GdkPixbuf *pixbuf; // input picture
guchar    *pixels; // picture byte array
bound_t   *bounds; // text string bounds positions
gint      bound_count=0; // bounds array size
gfloat    *brg; // brightness characteristic vector
gint      w; // image width in pixels
gint      h; // image height in pixels
gint      nch;   // channels number (bytes to pixels, nch=3 for RGB )
gint      rwstr; // bytes to rows

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
* load image from file to buffer                                  
*/
GdkPixbuf* img_load(char filename[]) {
   GdkPixbuf *pb;
   GError    *err=NULL;
   pb=gdk_pixbuf_new_from_file(filename,&err);
   if(err!=NULL){fprintf(stderr,err->message);g_error_free(err);return NULL;}
   return pb;
}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
* save image from buffer to file
*/
int img_save(GdkPixbuf *pb,char filename[]) {
   GError *err=NULL;
   g_return_val_if_fail(pb!=NULL,1);
   gdk_pixbuf_save(pb,filename,"bmp",&err,NULL);
   if(err!=NULL){fprintf(stderr,err->message);g_error_free(err);return 2;}
   return 0;
}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
int img_increase_point(gint num,gint d) {
   gint i,j;
  
   for( i=0 ; i<(rwstr*d) ; i+=rwstr){
      for( j=0 ; j<nch ; j++){ pixels[num+i+j]=0; }
   }
   return 0;
}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
int img_increase_points() {
   gint i,j,k;
   gint d=5; // point new size 

   for( j=0 ; j<(w-d) ; j++ ) {
	  for( i=0 ; i<(h-d) ; i++ ) {
		 k=(j*nch)+(i*rwstr);
	     if(pixels[k]<bcb){ img_increase_point(k,d); }
  	  }
   }
   return 0;
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
int img_high_contrast () {
   gchar c;
   gint  i,j,k,l;

   for( j=0 ; j<w ; j++ ) {
	  for( i=0 ; i<h ; i++ ) {
		 k=(j*nch)+(i*rwstr);
		 c=(pixels[k]>bcb)?bh:bl;
		 for( l=0 ; l<nch ; l++){ pixels[k+l]=c; }
  	  }
   }
   return 0;
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
int segm_init(gchar filename[]){
   gfloat d;

   pixbuf=img_load(filename);
   g_return_val_if_fail(pixbuf!=NULL,1);
   pixels=gdk_pixbuf_get_pixels(pixbuf);
   g_return_val_if_fail(pixels!=NULL,2);

   // get image parameters
   h=gdk_pixbuf_get_height(pixbuf);
   w=gdk_pixbuf_get_width(pixbuf);
   nch=gdk_pixbuf_get_n_channels (pixbuf);
   rwstr=gdk_pixbuf_get_rowstride(pixbuf);

   // image segments size in pixels to check word
   d=(gfloat)(h)/BASE_HEIGHT;
   if(d<1.0){d1=2;d2=4;}else{d1=(gint)(d*2.0);d2=(gint)(d*4.0);}

   // brightness characteristic vector
   brg=g_malloc(w*sizeof(gfloat));
   g_return_val_if_fail(brg!=NULL,3);
   memset(brg,0,w*sizeof(gfloat));

   // text string bounds positions
//                                 bounds=g_malloc(h*sizeof(bound_t));
   bounds=g_malloc(w*sizeof(bound_t));
   g_return_val_if_fail(bounds!=NULL,4);

   return 0;
}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
* check text string begin
*/
gboolean is_word_start(gint col) {
   gboolean res;
   gint i;
   res=(brg[col]>b1);
   for( i=1 ; i<d1 ; i++) { res = res && (brg[col-i]<b1); }
   for( i=1 ; i<d1 ; i++) { res = res && (brg[col+i]>b1); }
   return res;
}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
* check text string end
*/
gboolean is_word_end(gint col) {
   gboolean res;
   gint i;
   res=(brg[col]<b2);
   for( i=1 ; i<d1 ; i++) { res = res && (brg[col-i]>b2); }
   for( i=1 ; i<d2 ; i++) { res = res && (brg[col+i]<b2); }
   return res;
}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
* make segmentation
*/
int find_bounds() {
   gboolean fword=0;
   gint j;
   
   bound_count=0;
   fword=0; 
   for( j=d1; j<(w-d2+1) ; j++ ) { // text string proccessed
	  if(fword){ // word begin, check word end
		 if(is_word_end(j)){ // word end detected
		    fword=0;
		    bounds[bound_count].end=j;
			bound_count++;
		 }
	  } else { // check word begin
		 if(is_word_start(j)){ // text string begin detected
		    fword=1;
		    bounds[bound_count].begin=j;
		 }
	  }
   }
   //correct last pixels
   if(fword){ // make last bound
      bounds[bound_count++].end=(w-1);fword=0; 
   } else { // check last bound position
      bounds[bound_count].end=
	     (bounds[bound_count].end>(w-1))?(w-1):bounds[bound_count].end; 
   }
   return 0;
}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
* make rows brightness characteristic
*/
int write_out(gchar *outfile) {
   gint i,j,k;
     
   for( j=0 ; j<bound_count ; j++ ) {
	  for( i=0 ; i<h ; i++ ) { 
		 k=(bounds[j].begin*nch)+(i*rwstr); 
		 // start word line
		 if(nch==3){ // green line (only for RGB image)
			pixels[k+0]=0; pixels[k+1]=254; pixels[k+2]=0; 
		 } else { // black line
			pixels[k]=0; 
		 }
  	  } 
      for( i=0 ; i<h ; i++ ) { 
		 k=(bounds[j].end*nch)+(i*rwstr); 
		 // stop word line
		 if(nch==3){// red line (only for RGB image)
			pixels[k+0]=254; pixels[k+1]=0; pixels[k+2]=0; 
		 } else { // black line 
			pixels[k]=0; 
		 }
	  } 
   }
   img_save(pixbuf,outfile);
   return 0;
}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
int segm_destroy(){
   if(pixbuf!=NULL){gdk_pixbuf_unref(pixbuf);}
   if(brg!=NULL){ g_free(brg);}
   if(bounds!=NULL){g_free(bounds);}
   return 0;
}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
* make brightness characteristic vector
*/
int columns_characteristic(){
   guchar *p;
   gint   i,j;

   for( i=0 ; i<w ; i++ ) { 
      for( j=0 ; j<h ; j++ ) {
		 p=pixels+(j*rwstr)+(i*nch); 
		 brg[i]+=( B_HIGH - p[0]); 
      }
 	  brg[i]=brg[i]/h;
   }
   return 0;
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
int write_out_separate(gchar* inputfile,gchar* outdir) {
   GdkPixbuf* pb;
   guchar *p_src;
   guchar *p_trg;
   gchar f[10];
   gint i,j,strw,rwstr_trg;

   if(!g_file_test(outdir,G_FILE_TEST_IS_DIR)) { 
	  fprintf(stderr,"bad folder %s\n",outdir);
	  return 1; 
   }

   for( i=0 ; i<bound_count ; i++ ){
 	  strw=bounds[i].end-bounds[i].begin;
	  pb=gdk_pixbuf_new(gdk_pixbuf_get_colorspace(pixbuf),
	                 gdk_pixbuf_get_has_alpha(pixbuf), 
					 gdk_pixbuf_get_bits_per_sample(pixbuf),
					 strw,
					 gdk_pixbuf_get_height(pixbuf));
	  g_return_val_if_fail(pb!=NULL,1);

	  p_trg=gdk_pixbuf_get_pixels(pb); 
	  g_return_val_if_fail(pixels!=NULL,2);

	  rwstr_trg=gdk_pixbuf_get_rowstride(pb);
	  
 	  p_src=pixels+bounds[i].begin*nch;

	  for( j=0 ; j<h ; j++ ){
		 memcpy((p_trg+j*rwstr_trg),(p_src+j*rwstr),rwstr_trg);
	  }

	  if(i<10) {
	     sprintf(f,"%s/%s-0%i.bmp",outdir,inputfile,i);
	  } else {
	     sprintf(f,"%s/%s-%i.bmp",outdir,inputfile,i);
	  }
	  img_save(pb,f);
	  gdk_pixbuf_unref(pb);
   }
   return 0;
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
int main(int argc, char *argv[]) {
   gchar outfile[100];
   gchar outdir[100];

   gdk_init(&argc, &argv);

   switch(argc) {
	  case 2: sprintf(outfile,"0.bmp");sprintf(outdir,"out");break;
	  case 3: strncpy(outfile,argv[2],100);sprintf(outdir,"out");break;
	  case 4: strncpy(outfile,argv[2],100);strncpy(outdir,argv[3],100); break;
	  default:fprintf(stderr,"%s <input> [outfile] [outdir]\n",argv[0]);return 4;
   }

   if(segm_init(argv[1])){segm_destroy();return 1;}

   img_high_contrast();
   img_increase_points();

   columns_characteristic();
   find_bounds();

   gdk_pixbuf_unref(pixbuf);
   pixbuf=img_load(argv[1]);
   if(pixbuf==NULL){ segm_destroy(); }
   pixels=gdk_pixbuf_get_pixels(pixbuf); 
   if(pixels==NULL){ segm_destroy(); }

   write_out_separate(basename(argv[1]),outdir);
   write_out(outfile);
   segm_destroy();
   return 0;
}

/*
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
int print_s(){
   gint i;
   for( i=0 ; i<w ; i++ ) { fprintf(stdout,"%f\n",brg[i]); }
   fprintf(stdout,"b1:%f  b2:%f\n",b1,b2);
   return 0;
}
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
int print_bounds(){
   gint j;
   for( j=0 ; j<bound_count ; j++ ) {
	  fprintf(stdout,"%i %i\n", bounds[j].begin, bounds[j].end);
   }
   return 0;
}
*/



