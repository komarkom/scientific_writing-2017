/************************************************************
* $Id: main.c,v 1.11.1.3.1.2 2008/01/09 11:46:36 mechanoid Exp mechanoid $
*      
* OCR: line segmentator
*
*       OS : FreeBSD 6.2
* COMPILER : GNU project C and C++ Compiler (gcc 3.4.6)
*   AUTHOR : Evgeny S. Borisov
*
*  Glushkov Institute of Cybernetics
*  National Academy of Sciences of Ukraine
* 
*    http://www.mechanoid.kiev.ua
*  e-mail: ocr@mechanoid.kiev.ua
* 
************************************************************/
#include <gdk/gdk.h>
#include <stdio.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include <errno.h>
#include <math.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/uio.h>
#include <unistd.h>
#include <fcntl.h>

#define B_MEAN    20.0
#define B1_FACTOR 0.6
#define B2_FACTOR 0.4
#define B_HIGH    255
#define S1_FACTOR  0.6
#define S2_FACTOR  0.75

typedef struct {
	gint begin;
	gint end;
} str_bound_t; 

GdkPixbuf   *pixbuf=NULL; // input picture
guchar      *pixels; // picture byte array
gfloat      *brg; // brightness characteristic vector
str_bound_t *bounds; // text string bounds positions
gint        bound_count=0; // bounds array size

gfloat      bm=B_MEAN; // image mean brightness
gfloat      b1=B_MEAN*B1_FACTOR; // top bound brightness
gfloat      b2=B_MEAN*B2_FACTOR; // bottom bound brightness
gint        w; // image width in pixels
gint        h; // image height in pixels
gint        nch; // channels number (bytes to pixels, nch=3 for RGB )
gint        rwstr; // bytes to rows

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
* load image from file to buffer                                  
*/
GdkPixbuf* img_load(char filename[]) {
   GdkPixbuf *pb;
   GError    *err=NULL;
   pb=gdk_pixbuf_new_from_file(filename,&err);
   if(err!=NULL){fprintf(stderr,err->message);g_error_free(err);return NULL;}
   return pb;
}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
* save image from buffer to file
*/
int img_save(GdkPixbuf *pb,char filename[]) {
   GError *err=NULL;
   g_return_val_if_fail(pb!=NULL,1);
   gdk_pixbuf_save(pb,filename,"bmp",&err,NULL);
   if(err!=NULL){fprintf(stderr,err->message);g_error_free(err);return 2;}
   return 0;
}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
gint make_init(char filename[]){
   pixbuf=img_load(filename); 
   g_return_val_if_fail(pixbuf!=NULL,1);

   pixels=gdk_pixbuf_get_pixels(pixbuf); 
   g_return_val_if_fail(pixels!=NULL,2);

   h=gdk_pixbuf_get_height(pixbuf);
   w=gdk_pixbuf_get_width(pixbuf);
   nch=gdk_pixbuf_get_n_channels (pixbuf);
   rwstr=gdk_pixbuf_get_rowstride(pixbuf);

   brg=g_malloc(h*sizeof(gfloat));
   g_return_val_if_fail(brg!=NULL,3);
   memset(brg,0,h*sizeof(gfloat));

   bounds=g_malloc(h*sizeof(str_bound_t)); 
   g_return_val_if_fail(bounds!=NULL,4);
	  
   return 0;
}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
gint make_destroy(){
   if(pixbuf!=NULL){gdk_pixbuf_unref(pixbuf);}
   if(brg!=NULL){ g_free(brg);}
   if(bounds!=NULL){g_free(bounds);}
   return 0;
}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
* make rows brightness characteristic
*/
int make_out(gchar* outfile) {
   int i,j,k;
     
   for( j=0 ; j<bound_count ; j++ ) {
	  for( i=0 ; i<w ; i++ ) {// start word line
		 k=(bounds[j].begin*rwstr)+(i*nch); 
		 if(nch==3) {// green line (only for RGB image)
		    pixels[k+0]=0; pixels[k+1]=255; pixels[k+2]=0; 
		 } else {// black line
		    pixels[k]=0; 
		 }
  	  } 
      for( i=0 ; i<w ; i++ ) {// stop word line
		 k=(bounds[j].end*rwstr)+(i*nch); 
		 if(nch==3) {// red line (only for RGB image)
		    pixels[k+0]=255; pixels[k+1]=0; pixels[k+2]=0; 
		 } else {// black line
		    pixels[k]=0; 
		 }
	  } 
   }
   img_save(pixbuf,outfile);
   return 0;
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
int make_out_separate(gchar* outdir) {
   GdkPixbuf* pb;
   guchar *data;
   gchar f[10];
   gint i;

   if(!g_file_test(outdir,G_FILE_TEST_IS_DIR)){ 
	  fprintf(stderr,"bad folder %s\n",outdir);
	  return 1; 
   }
   for( i=0 ; i<bound_count ; i++ ){
	  data=pixels+bounds[i].begin*rwstr;
	  pb=gdk_pixbuf_new_from_data(data,
			 gdk_pixbuf_get_colorspace(pixbuf),
			 gdk_pixbuf_get_has_alpha(pixbuf),
			 gdk_pixbuf_get_bits_per_sample(pixbuf),
			 gdk_pixbuf_get_width (pixbuf),
			 bounds[i].end-bounds[i].begin,
			 rwstr,
			 NULL,
			 NULL);
	  g_return_val_if_fail(pb!=NULL,1);
	  if(i<10){
	     sprintf(f,"%s/0%i.bmp",outdir,i);
	  }else{
	     sprintf(f,"%s/%i.bmp",outdir,i);
	  }
	  img_save(pb,f);
   	  gdk_pixbuf_unref(pb);
   }
   return 0;
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
* make brightness characteristic vector
*/
int make_row_characteristic(){
   guchar *p;
   gint i,j,k;
   gfloat pix=0.0;

   for( j=0 ; j<h ; j++ ) {
	  for( i=0 ; i<w ; i++ ) { 
		 p=pixels+(j*rwstr)+(i*nch); 
		 //make grayscale from RGB
		 for( pix=0,k=0 ; k<nch ; k++ ){ pix+=p[k];} 
		 brg[j]+=(B_HIGH - (pix/nch)); 
	  }
 	  brg[j]=brg[j]/w;
   }
   return 0;
}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
* check text string begin
*/
gboolean is_string_start(gint j) {
   gboolean res;
   res=(brg[j-2]<b1)&&
	   (brg[j-1]<b1)&&
	   (brg[j+0]>b1)&&
	   (brg[j+1]>b2)&&
	   (brg[j+2]>b2)&&
	   (brg[j+3]>b2);
   return res;
}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
* check text string begin
*/
gboolean is_string_end(gint j) {
   gboolean res;
   res=(
		 (brg[j+0]>b1)&&
		 (brg[j+1]<b2)
	   )||(
		 (brg[j+1]<b2)&&
		 (brg[j+2]<b2)&&
		 (brg[j+3]<b2)
	   );
   return res;
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
* make segmentation
*/
int make_segmentation() {
   gboolean fstr=0;
   gint j,min_str_size,buf;

   for( bound_count=0,min_str_size=h,fstr=0,j=2 ; j<(h-3) ; j++ ) {
	  if(fstr){// text string proccessed
		 if(is_string_end(j)){ // text string end detected
		    fstr=0; 
		    bounds[bound_count].end=j;
            buf=bounds[bound_count].end-bounds[bound_count].begin;
            min_str_size=(min_str_size>buf)?buf:min_str_size;
			bound_count++;
		 }
	  } else {
		if(is_string_start(j)){ // text string begin detected
		   fstr=1;
		   bounds[bound_count].begin=j;
		}
	  }
   }
   //correct last pixels
   if(fstr){ bounds[bound_count++].end=(h-1);fstr=0; }
   // increase string bounds interval for capital letters	  
   for( j=0 ; j<bound_count ; j++ ) {
		 buf=bounds[j].begin-(min_str_size*S1_FACTOR);
		 bounds[j].begin=(buf<0)?0:buf;
		 buf=bounds[j].end+(min_str_size*S2_FACTOR);
		 bounds[j].end=(buf>(h-1))?(h-1):buf;
   }
   return 0;
}

/* - - - - - - - - - - - - - - - - - - - */
int main(int argc, char *argv[]) {
   gchar outfile[100];
   gchar outdir[100];

   switch(argc) {
	  case 2: sprintf(outfile,"0.bmp");sprintf(outdir,"out");break;
	  case 3: strncpy(outfile,argv[2],100);sprintf(outdir,"out");break;
	  case 4: strncpy(outfile,argv[2],100);strncpy(outdir,argv[3],100); break;
	  default:fprintf(stderr,"%s <input> [outfile] [outdir]\n",argv[0]);return 4;
   }

   gdk_init(&argc, &argv);
   if(make_init(argv[1])){make_destroy();return 1;}
   make_row_characteristic();
   make_segmentation();
   make_out_separate(outdir);
   make_out(outfile);
   make_destroy();
   return 0;
}
